from pydantic import BaseModel
from typing import Dict

class GraphState(BaseModel):
    call_summary: str
    criminality_result: Dict = {}
    insensitivity_result: Dict = {}
    stereotype_result: Dict = {}
    profanity_result: Dict = {}
    pii_result: Dict = {}
    unethical_result: Dict = {}

    metadata: Dict = {}