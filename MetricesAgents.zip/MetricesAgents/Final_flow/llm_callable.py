
from langchain_openai import AzureChatOpenAI

def get_llm(api_key: str, api_version: str, azure_deployment: str, azure_endpoint: str):
    return AzureChatOpenAI(
        api_key=api_key,  # Replace with valid Azure OpenAI API key
        api_version=api_version,  # Recent version
        azure_deployment=azure_deployment,  # Ensure this matches your Azure deployment name
        azure_endpoint=azure_endpoint,  # Replace with valid endpoint, e.g., https://<your-resource>.openai.azure.com/
        response_format={"type": "json_object"},  # Enforce JSON output
        temperature=0  # Reduce randomness for consistent JSON output
    )
