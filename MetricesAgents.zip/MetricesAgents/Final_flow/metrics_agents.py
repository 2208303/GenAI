from datetime import datetime
from typing import Dict, Any
from langchain_core.runnables import RunnableLambda
from configuration.logger import log_trace
from graph_state import GraphState
import json
import openai
import re

class MetricsAgents:
    def __init__(self, llm):
        self.llm = llm

    def criminality_agent(self) -> RunnableLambda:
        def run(state: GraphState) -> Dict[str, Any]:
            log_id = state.metadata.get("start_time", datetime.now().isoformat())
            log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename

            log_trace(log_id, "criminality_agent_input", {"state": state.model_dump()})

            criminality_prompt = (
                "You are an AI language model specialized in legal text analysis and detection of potentially criminal content in communication. "
                "Instructions: Carefully review the provided text and identify any explicit or implicit references to criminal behavior. "
                "For each instance, provide: "
                "- A description of the language used. "
                "- The nature of the potential crime. "
                "- The reasoning why this could be considered illegal or suspicious under typical criminal law. "
                "- Whether the behavior is clearly criminal, potentially criminal, or unlikely to be criminal. "
                "Where: "
                "• N_clear = number of clearly criminal references. "
                "• N_potential = number of possibly or ambiguously criminal references. "
                "• N_unlikely = references flagged as suspicious but unlikely to be criminal. "
                "Return your output **strictly as a valid JSON object** with the following structure. "
                "Do not include markdown, code fences (```), comments, or any text outside the JSON object. "
                "Ensure the output is a single, well-formed JSON object that can be parsed by a JSON parser. "
                "{{ "
                "  \"N_clear\": <integer>, "
                "  \"N_potential\": <integer>, "
                "  \"N_unlikely\": <integer>, "
                "  \"Reasoning\": \"<single paragraph explaining the judgment, specifying what was flagged and why, including: "
                "      Description: Description of the language used. "
                "      Nature: Nature of the potential crime. "
                "      Reasoning: Explanation of why this could be considered illegal or suspicious. "
                "      Classification: Clearly Criminal|Potentially Criminal|Unlikely to be Criminal\" "
                "}} "
                "Text to analyze: '''{call_summary}'''"
            ).format(call_summary=state.call_summary)

            try:
                output = self.llm.invoke(criminality_prompt)
                raw_output = output.content if hasattr(output, 'content') else str(output)
                log_trace(log_id, "criminality_agent_raw_output", {"raw_output": raw_output})
            except openai.APIConnectionError as e:
                result = {
                    "N_clear": 0,
                    "N_potential": 0,
                    "N_unlikely": 0,
                    "Reasoning": f"Error: Failed to connect to Azure OpenAI API: {str(e)}. No criminal behavior analysis performed."
                }
                log_trace(log_id, "criminality_agent_error", {"error": str(e), "result": result})
                print(f"Criminality Agent Error: {result}")
                return {"criminality_result": result}

            try:
                cleaned_output = re.sub(r'^```json\s*|\s*```$|^\s*//.*$|^\s*#[^\n]*$', '', raw_output.strip(), flags=re.MULTILINE)
                result = json.loads(cleaned_output)
            except json.JSONDecodeError as e:
                result = {
                    "N_clear": 0,
                    "N_potential": 0,
                    "N_unlikely": 0,
                    "Reasoning": f"Error: LLM output was not valid JSON: {str(e)}. Raw output: {raw_output[:100]}... No criminal behavior detected."
                }

            log_trace(log_id, "criminality_agent", {"raw_output": raw_output, "parsed_result": result})
            print(f"Criminality Agent Output: {result}")
            return {"criminality_result": result}

        return RunnableLambda(run)

    def insensitivity_agent(self) -> RunnableLambda:
        def run(state: GraphState) -> Dict[str, Any]:
            log_id = state.metadata.get("start_time", datetime.now().isoformat())
            log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename

            log_trace(log_id, "insensitivity_agent_input", {"state": state.model_dump()})

            insensitivity_prompt = (
                "You are an AI language model specialized in detecting insensitivity in communication. "
                "Insensitivity is defined as language or behavior that fails to acknowledge or respect others' feelings, experiences, or social norms, "
                "even if not malicious. Review the provided text for any such language or terms. "
                "For each identified instance, provide a brief explanation of the statement identified as insensitive. "
                "Example: 'Why can't you just get over it? It's not a big deal.' is insensitive to someone sharing a serious concern. "
                "Calculate a score using the formula: Score = (Number of insensitive words) / (Total number of words). "
                "Return your output **strictly as a valid JSON object** with the following structure. "
                "Do not include markdown, code fences (```), comments, or any text outside the JSON object. "
                "Ensure the output is a single, well-formed JSON object that can be parsed by a JSON parser. "
                "{{ "
                "  \"score\": <float, rounded to 4 decimal places>, "
                "  \"reasoning\": \"<list of identified insensitive statements, each with the statement and explanation, or 'No insensitive language detected.'>\" "
                "}} "
                "Text to analyze: '''{call_summary}'''"
            ).format(call_summary=state.call_summary)

            try:
                output = self.llm.invoke(insensitivity_prompt)
                raw_output = output.content if hasattr(output, 'content') else str(output)
                log_trace(log_id, "insensitivity_agent_raw_output", {"raw_output": raw_output})
            except openai.APIConnectionError as e:
                result = {
                    "score": 0.0,
                    "reasoning": f"Error: Failed to connect to Azure OpenAI API: {str(e)}. No insensitivity analysis performed."
                }
                log_trace(log_id, "insensitivity_agent_error", {"error": str(e), "result": result})
                print(f"Insensitivity Agent Error: {result}")
                return {"insensitivity_result": result}

            try:
                cleaned_output = re.sub(r'^```json\s*|\s*```$|^\s*//.*$|^\s*#[^\n]*$', '', raw_output.strip(), flags=re.MULTILINE)
                result = json.loads(cleaned_output)
            except json.JSONDecodeError as e:
                result = {
                    "score": 0.0,
                    "reasoning": f"Error: LLM output was not valid JSON: {str(e)}. Raw output: {raw_output[:100]}... No insensitivity analysis performed."
                }

            log_trace(log_id, "insensitivity_agent", {"raw_output": raw_output, "parsed_result": result})
            print(f"Insensitivity Agent Output: {result}")
            return {"insensitivity_result": result}

        return RunnableLambda(run)

    def stereotype_agent(self) -> RunnableLambda:
        def run(state: GraphState) -> Dict[str, Any]:
            log_id = state.metadata.get("start_time", datetime.now().isoformat())
            log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename

            log_trace(log_id, "stereotype_agent_input", {"state": state.model_dump()})

            stereotypes_prompt = (
                "You are an AI language model specialized in detecting stereotypes in text. "
                "A stereotype is a generalized or oversimplified belief about a particular group of people, often based on assumptions, biases, or cultural perceptions. "
                "Focus on statements that make generalized assumptions about groups based on gender, race, age, culture, profession, etc. "
                "Split the text into logical statements or sentences. Identify which statements exhibit stereotyping. "
                "Calculate a score using the formula: Score = min(1, 0.25 * Number of stereotypical statements), rounded to 4 decimal places. "
                "Return your output **strictly as a valid JSON object** with the following structure. "
                "Do not include markdown, code fences (```), comments, or any text outside the JSON object. "
                "Ensure the output is a single, well-formed JSON object that can be parsed by a JSON parser. "
                "{ "
                "  \"score\": <float, rounded to 4 decimal places>, "
                "  \"reasoning\": \"<list of identified stereotypical statements, each with the statement and explanation, or 'No stereotypical statements detected.'>\" "
                "} "
                "Text to analyze: '''{call_summary}'''"
            ).format(call_summary=state.call_summary)

            try:
                output = self.llm.invoke(stereotypes_prompt)
                raw_output = output.content if hasattr(output, 'content') else str(output)
                log_trace(log_id, "stereotype_agent_raw_output", {"raw_output": raw_output})
            except openai.APIConnectionError as e:
                result = {
                    "score": 0.0,
                    "reasoning": f"Error: Failed to connect to Azure OpenAI API: {str(e)}. No stereotype analysis performed."
                }
                log_trace(log_id, "stereotype_agent_error", {"error": str(e), "result": result})
                print(f"Stereotype Agent Error: {result}")
                return {"stereotype_result": result}

            try:
                cleaned_output = re.sub(r'^```json\s*|\s*```$|^\s*//.*$|^\s*#[^\n]*$', '', raw_output.strip(),
                                        flags=re.MULTILINE)
                result = json.loads(cleaned_output)
            except json.JSONDecodeError as e:
                result = {
                    "score": 0.0,
                    "reasoning": f"Error: LLM output was not valid JSON: {str(e)}. Raw output: {raw_output[:100]}... No stereotype analysis performed."
                }

            log_trace(log_id, "stereotype_agent", {"raw_output": raw_output, "parsed_result": result})
            print(f"Stereotype Agent Output: {result}")
            return {"stereotype_result": result}

        return RunnableLambda(run)

    def profanity_agent(self) -> RunnableLambda:
        def run(state: GraphState) -> Dict[str, Any]:
            log_id = state.metadata.get("start_time", datetime.now().isoformat())
            log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename

            log_trace(log_id, "profanity_agent_input", {"state": state.model_dump()})

            profanity_prompt = (
                "You are an AI language model specialized in detecting profanity in the text. "
        "What qualifies as profanity is the use of explicit, vulgar, or obscene language, often considered offensive or inappropriate in most social or professional contexts."
        "Consider it as profanity only if it has the following characteristics - includes swear words, slurs, or explicit sexual language.May not necessarily convey hostility or harm but can still be offensive based on cultural norms."
        "Consider the following example before analyzing the summary - This is so f***ing annoying!. This is Profane but not necessarily toxic or insensitive in intent."
        "Rate the profanity on a scale of 0 to 1, where 0 means no profanity and 1 means extreme profanity. "
        "Be as specific as possible and provide reasoning behind your judgment. "
        "Return a clear output with 'Score:' followed by the numeric score and 'Reasoning:' followed by only the "
        "reasoning."
        "Text to analyze: '''{call_summary}'''"
            ).format(call_summary=state.call_summary)

            try:
                output = self.llm.invoke(profanity_prompt)
                raw_output = output.content if hasattr(output, 'content') else str(output)
                log_trace(log_id, "profanity_agent_raw_output", {"raw_output": raw_output})
            except openai.APIConnectionError as e:
                result = {
                    "score": 0.0,
                    "reasoning": f"Error: Failed to connect to Azure OpenAI API: {str(e)}. No profanity analysis performed."
                }
                log_trace(log_id, "criminality_agent_error", {"error": str(e), "result": result})
                print(f"profanity Agent Error: {result}")
                return {"profanity_result": result}

            try:
                cleaned_output = re.sub(r'^```json\s*|\s*```$|^\s*//.*$|^\s*#[^\n]*$', '', raw_output.strip(), flags=re.MULTILINE)
                result = json.loads(cleaned_output)
            except json.JSONDecodeError as e:
                result = {
                     "score": 0.0,
                    "reasoning": f"Error: LLM output was not valid JSON: {str(e)}. Raw output: {raw_output[:100]}... No profanity analysis performed."
                }

            log_trace(log_id, "profanity_agent", {"raw_output": raw_output, "parsed_result": result})
            print(f"profanity Agent Output: {result}")
            return {"profanity_result": result}

        return RunnableLambda(run)

    def pii_detection_agent(self) -> RunnableLambda:
        def run(state: GraphState) -> Dict[str, Any]:
            log_id = state.metadata.get("start_time", datetime.now().isoformat())
            log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename

            log_trace(log_id, "pii_agent_input", {"state": state.model_dump()})

            pii_prompt = (
                 "You are an AI language model specialized in detecting Personally Identifiable Information (PII) in text. "
        "Your task is to analyze the provided text and identify any unnecessary PII that should not be shared in the context "
        "of a travel booking conversation. Note that required details essential for completing a booking (e.g., names, "
        "basic contact information) should not be flagged as PII, as they are necessary for the process. However, any "
        "unnecessary information, such as credit card numbers, social security numbers, or other sensitive data that "
        "goes beyond what is required for the booking, should be flagged. "
        "\n\nPII includes, but is not limited to, the following types of data:\n"
        "- Unnecessary financial information: Credit card numbers, CVV codes, bank account details, etc.\n"
        "- Government-issued identification numbers: Social security numbers, passport numbers, etc., unless required for the booking.\n"
        "- Excessive personal details: Information unrelated to the booking, such as personal anecdotes or unrelated addresses.\n"
        "\nAssign a score between 0 and 1:\n"
        "- '1' means unnecessary PII is observed.\n"
        "- '0' means no unnecessary PII is observed.\n"
        "\nBe specific and provide reasoning for your judgment. Clearly identify whether the flagged information is unnecessary "
        "in the travel booking context and explain why.\n"
        "Return a clear output with 'Score:' followed by the numeric score and 'Reasoning:' followed by only the "
        "reasoning."
        "Text to analyze: '''{call_summary}'''"
            ).format(call_summary=state.call_summary)

            try:
                output = self.llm.invoke(pii_prompt)
                raw_output = output.content if hasattr(output, 'content') else str(output)
                log_trace(log_id, "pii_agent_raw_output", {"raw_output": raw_output})
            except openai.APIConnectionError as e:
                result = {
                    "score": 0.0,
                    "reasoning": f"Error: Failed to connect to Azure OpenAI API: {str(e)}. No profanity analysis performed."
                }
                log_trace(log_id, "pii_agent_error", {"error": str(e), "result": result})
                print(f"pii Agent Error: {result}")
                return {"pii_result": result}

            try:
                cleaned_output = re.sub(r'^```json\s*|\s*```$|^\s*//.*$|^\s*#[^\n]*$', '', raw_output.strip(), flags=re.MULTILINE)
                result = json.loads(cleaned_output)
            except json.JSONDecodeError as e:
                result = {
                     "score": 0.0,
                    "reasoning": f"Error: LLM output was not valid JSON: {str(e)}. Raw output: {raw_output[:100]}... No pii analysis performed."
                }

            log_trace(log_id, "pii_agent", {"raw_output": raw_output, "parsed_result": result})
            print(f"pii Agent Output: {result}")
            return {"pii_result": result}

        return RunnableLambda(run)



    def unethical_agent(self) -> RunnableLambda:
        def run(state: GraphState) -> Dict[str, Any]:
            log_id = state.metadata.get("start_time", datetime.now().isoformat())
            log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename

            log_trace(log_id, "unethical_input", {"state": state.model_dump()})

            is_unethical_prompt = (
                  "You are an AI language model specialized in detecting unethical behaviour in the text such as asking for card details such as cvv number, otp number. "
        "Unethical behaviour also includes scenarios where the person is trying to trick someone to provide bank password details, card related sensitive information etc."
        "Count total number of sentences in text that are unethical in nature"
        "Count total number of sentences in text"

        "Be as specific as possible and provide reasoning behind your judgment.\n\n"
        "Return output strictly as json format with the following keys:\n"
        "  unethical_sentence_count: total number of sentences with unethical behaviour in summary text, "
        "  total_sentence_count:Total number of sentences in Summary text  "
        "  reasoning: brief explanation identifying unethical sentences and why they are considered unethical"

        "Text to analyze: '''{call_summary}'''"
            ).format(call_summary=state.call_summary)

            try:
                output = self.llm.invoke(is_unethical_prompt)
                raw_output = output.content if hasattr(output, 'content') else str(output)
                log_trace(log_id, "unethical_agent_raw_output", {"raw_output": raw_output})
            except openai.APIConnectionError as e:
                result = {
                    "score": 0.0,
                    "reasoning": f"Error: Failed to connect to Azure OpenAI API: {str(e)}. No unethical analysis performed."
                }
                log_trace(log_id, "unethical_agent_error", {"error": str(e), "result": result})
                print(f"unethical Agent Error: {result}")
                return {"unethical_result": result}

            try:
                cleaned_output = re.sub(r'^```json\s*|\s*```$|^\s*//.*$|^\s*#[^\n]*$', '', raw_output.strip(), flags=re.MULTILINE)
                result = json.loads(cleaned_output)
            except json.JSONDecodeError as e:
                result = {
                     "score": 0.0,
                    "reasoning": f"Error: LLM output was not valid JSON: {str(e)}. Raw output: {raw_output[:100]}... No unethical analysis performed."
                }

            log_trace(log_id, "unethical_agent", {"raw_output": raw_output, "parsed_result": result})
            print(f"unethical Agent Output: {result}")
            return {"unethical_result": result}

        return RunnableLambda(run)

