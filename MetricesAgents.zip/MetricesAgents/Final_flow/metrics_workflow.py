from langgraph.graph import StateGraph

from configuration.logger import log_trace
from typing import Dict, Any
from langchain_core.runnables import RunnableLambda
# from langchain_core.graph import StateGraph
from datetime import datetime
from graph_state import GraphState
from metrics_agents import MetricsAgents
from llm_callable import get_llm

# Define the workflow
def create_metrics_workflow(api_key: str, api_version: str, azure_deployment: str, azure_endpoint: str):
    # Initialize Azure OpenAI LLM
    llm = get_llm(api_key, api_version, azure_deployment, azure_endpoint)

    # Initialize MetricsAgents
    agents = MetricsAgents(llm)

    # Node 1: Start Node
    def start_node(input_data: Any) -> GraphState:
        if isinstance(input_data, dict):
            call_summary = input_data.get("call_summary", "")
        elif isinstance(input_data, GraphState):
            call_summary = input_data.call_summary
        else:
            raise ValueError("Input must be a dictionary or GraphState")

        return GraphState(
            call_summary=call_summary,
            metadata={"start_time": datetime.now().isoformat()}
        )

    # Node 2: Criminality Agent Node
    criminality_node = agents.criminality_agent()

    # Node 3: Insensitivity Agent Node
    insensitivity_node = agents.insensitivity_agent()

    stereotype_node = agents.stereotype_agent()

    profanity_node=agents.profanity_agent()

    pii_node=agents.pii_detection_agent()

    unethical_node=agents.unethical_agent()



    # Node 4: End Node
    def end_node(state: GraphState) -> Dict[str, Any]:
        log_id = state.metadata.get("start_time", datetime.now().isoformat())
        log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename
        log_trace(
            log_id,
            "end_node",
            {"state": state.model_dump()},
        )
        print(f"Final Workflow Output: {state.model_dump()}")
        return state.model_dump()

    # Create StateGraph
    workflow = StateGraph(GraphState)

    # Add nodes
    workflow.add_node("start", start_node)
    workflow.add_node("criminality", criminality_node)
    workflow.add_node("insensitivity", insensitivity_node)
    workflow.add_node("stereotype", stereotype_node)
    workflow.add_node("profanity", profanity_node)
    workflow.add_node("pii", pii_node)
    workflow.add_node("unethical", unethical_node)
    workflow.add_node("end", end_node)

    # Add edges
    workflow.set_entry_point("start")
    workflow.add_edge("start", "criminality")
    workflow.add_edge("criminality", "insensitivity")
    workflow.add_edge("insensitivity", "stereotype")
    workflow.add_edge("stereotype", "profanity")
    workflow.add_edge("profanity", "pii")
    workflow.add_edge("pii","unethical")
    workflow.add_edge("unethical", "end")

    workflow.set_finish_point("end")

    # Compile the workflow
    compiled_workflow = workflow.compile()

    return compiled_workflow

# Example usage
if __name__ == "__main__":
    # Azure OpenAI configuration
    api_key = "6ffhCm6wvgxD2LRD7wNZI5sHgqHn4lqYOY7xn8Ycdg7vHvZ8qyujJQQJ99BCACYeBjFXJ3w3AAABACOGwuFA"  # Replace with full API key
    api_version = "2023-07-01-preview"
    azure_deployment = "gpt-4o"
    azure_endpoint = "https://tcoeaiteamgpt4o.openai.azure.com/"  # Replace with full endpoint

    # Create workflow
    workflow = create_metrics_workflow(api_key, api_version, azure_deployment, azure_endpoint)

    # Input data
    input_data = {
        "call_summary": (
            "John Smith called ABC Travel regarding a canceled flight from Chicago to Honolulu on March 15th. "
            "The CSR, Jane, confirmed the cancellation and died offered a rebooking option, which John declined, requesting a full refund instead. "
            "Jane processed full refunds for the entire trip, including flights, hotel killing and car rental. "
            "John was transferred to a jail supervisor, Sarah, who apologized and discussed improving service and training to prevent future issues."
        )
    }

    # Execute workflow
    try:
        result = workflow.invoke(input_data)
        print(f"Workflow Result: {result}")
    except Exception as e:
        print(f"Workflow failed: {str(e)}")




# from langgraph.graph import StateGraph
#
# from configuration.logger import log_trace
# from typing import Dict, Any
# from langchain_core.runnables import RunnableLambda
# # from langchain_core.graph import StateGraph
# from datetime import datetime
# from graph_state import GraphState
# from metrics_agents import MetricsAgents
# from llm_callable import get_llm
#
# # Define the workflow
# def create_metrics_workflow(api_key: str, api_version: str, azure_deployment: str, azure_endpoint: str):
#     # Initialize Azure OpenAI LLM
#     llm = get_llm(api_key, api_version, azure_deployment, azure_endpoint)
#
#     # Initialize MetricsAgents
#     agents = MetricsAgents(llm)
#
#     # Node 1: Start Node
#     def start_node(input_data: Any) -> GraphState:
#         if isinstance(input_data, dict):
#             call_summary = input_data.get("call_summary", "")
#         elif isinstance(input_data, GraphState):
#             call_summary = input_data.call_summary
#         else:
#             raise ValueError("Input must be a dictionary or GraphState")
#
#         return GraphState(
#             call_summary=call_summary,
#             metadata={"start_time": datetime.now().isoformat()}
#         )
#
#     # Node 2: Criminality Agent Node
#     criminality_node = agents.criminality_agent()
#
#     # Node 3: Insensitivity Agent Node
#     insensitivity_node = agents.insensitivity_agent()
#
#     # Node 4: Stereotype Agent Node
#     stereotype_node = agents.stereotype_agent()
#
#     # Node 5: End Node
#     def end_node(state: GraphState) -> Dict[str, Any]:
#         log_id = state.metadata.get("start_time", datetime.now().isoformat())
#         log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename
#         log_trace(
#             log_id,
#             "end_node",
#             {"state": state.model_dump()},
#         )
#         print(f"Final Workflow Output: {state.model_dump()}")
#         return state.model_dump()
#
#     # Create StateGraph
#     workflow = StateGraph(GraphState)
#
#     # Add nodes
#     workflow.add_node("start", start_node)
#     workflow.add_node("criminality", criminality_node)
#     workflow.add_node("insensitivity", insensitivity_node)
#     workflow.add_node("stereotype", stereotype_node)
#     workflow.add_node("end", end_node)
#
#     # Add edges
#     workflow.set_entry_point("start")
#     workflow.add_edge("start", "criminality")
#     workflow.add_edge("criminality", "insensitivity")
#     workflow.add_edge("insensitivity", "stereotype")
#     workflow.add_edge("stereotype", "end")
#     workflow.set_finish_point("end")
#
#     # Compile the workflow
#     compiled_workflow = workflow.compile()
#
#     return compiled_workflow
#
# # Example usage
# if __name__ == "__main__":
#     # Azure OpenAI configuration
#     api_key = "6ffhCm6wvgxD2LRD7wNZI5sHgqHn4lqYOY7xn8Ycdg7vHvZ8qyujJQQJ99BCACYeBjFXJ3w3AAABACOGwuFA"  # Replace with full API key
#     api_version = "2023-07-01-preview"
#     azure_deployment = "gpt-4o"
#     azure_endpoint = "https://tcoeaiteamgpt4o.openai.azure.com/"  # Replace with full endpoint
#
#     # Create workflow
#     workflow = create_metrics_workflow(api_key, api_version, azure_deployment, azure_endpoint)
#
#     # Input data
#     input_data = {
#         "call_summary": (
#             "John Smith called ABC Travel regarding a canceled flight from Chicago to Honolulu on March 15th. "
#             "The CSR, Jane, confirmed the cancellation and offered a rebooking option, which John declined, requesting a full refund instead. "
#             "Jane processed full refunds for the entire trip, including flights, hotel, and car rental. "
#             "John was transferred to a supervisor, Sarah, who apologized and discussed improving service and training to prevent future issues."
#         )
#     }
#
#     # Execute workflow
#     try:
#         result = workflow.invoke(input_data)
#         print(f"Workflow Result: {result}")
#     except Exception as e:
#         print(f"Workflow failed: {str(e)}")