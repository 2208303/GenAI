from langgraph.graph import StateGraph

from configuration.logger import log_trace
from pydantic import BaseModel
from typing import Dict, Any
from langchain_core.runnables import RunnableLambda, Runnable
from langchain_openai import AzureChatOpenAI
from langchain_core.runnables import RunnablePassthrough
# from langchain_core.graph import StateGraph

from datetime import datetime
import json
import openai
import re

# GraphState definition without ticket_id
class GraphState(BaseModel):
    call_summary: str
    criminality_result: Dict = {}
    metadata: Dict = {}

class MetricsAgents:
    def __init__(self, llm):
        self.llm = llm

    def criminality_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            # Generate a filename-safe log ID from timestamp
            log_id = state.metadata.get("start_time", datetime.now().isoformat())
            log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename

            # Log input state
            log_trace(
                log_id,
                "criminality_agent_input",
                {"state": state.model_dump()},
            )

            # Define the criminality prompt with explicit JSON instructions
            criminality_prompt = (
                "You are an AI language model specialized in legal text analysis and detection of potentially criminal content in communication. "
                "Instructions: Carefully review the provided text and identify any explicit or implicit references to criminal behavior. "
                "For each instance, provide: "
                "- A description of the language used. "
                "- The nature of the potential crime. "
                "- The reasoning why this could be considered illegal or suspicious under typical criminal law. "
                "- Whether the behavior is clearly criminal, potentially criminal, or unlikely to be criminal. "
                "Where: "
                "• N_clear = number of clearly criminal references. "
                "• N_potential = number of possibly or ambiguously criminal references. "
                "• N_unlikely = references flagged as suspicious but unlikely to be criminal. "
                "Return your output **strictly as a valid JSON object** with the following structure. "
                "Do not include markdown, code fences (```), comments, or any text outside the JSON object. "
                "Ensure the output is a single, well-formed JSON object that can be parsed by a JSON parser. "
                "{{ "
                "  \"N_clear\": <integer>, "
                "  \"N_potential\": <integer>, "
                "  \"N_unlikely\": <integer>, "
                "  \"Reasoning\": \"<single paragraph explaining the judgment, specifying what was flagged and why, including: "
                "  \"Description\": \"Description of the language used. "
                "  \"Nature\": \"Nature of the potential crime. "
                "  \"Reasoning\": \"Explanation of why this could be considered illegal or suspicious. "
                "  \"Classification\": \"Clearly Criminal|Potentially Criminal|Unlikely to be Criminal "
                "}} "
                "Text to analyze: '''{call_summary}'''"
            ).format(call_summary=state.call_summary)

            # Invoke the LLM with error handling
            try:
                output = self.llm.invoke(criminality_prompt)
                raw_output = output.content if hasattr(output, 'content') else str(output)
                # Log raw output for debugging
                log_trace(
                    log_id,
                    "criminality_agent_raw_output",
                    {"raw_output": raw_output},
                )
            except openai.APIConnectionError as e:
                result = {
                    "N_clear": 0,
                    "N_potential": 0,
                    "N_unlikely": 0,
                    "Reasoning": f"Error: Failed to connect to Azure OpenAI API: {str(e)}. No criminal behavior analysis performed."
                }
                log_trace(
                    log_id,
                    "criminality_agent_error",
                    {"error": str(e), "result": result},
                )
                print(f"Criminality Agent Error: {result}")
                return {"criminality_result": result}

            # Parse LLM output, handling potential markdown or non-JSON content
            try:
                # Strip markdown, code fences, extra whitespace, or comments
                cleaned_output = re.sub(r'^```json\s*|\s*```$|^\s*//.*$|^\s*#[^\n]*$', '', raw_output.strip(), flags=re.MULTILINE)
                result = json.loads(cleaned_output)
            except json.JSONDecodeError as e:
                result = {
                    "N_clear": 0,
                    "N_potential": 0,
                    "N_unlikely": 0,
                    "Reasoning": f"Error: LLM output was not valid JSON: {str(e)}. Raw output: {raw_output[:100]}... No criminal behavior detected."
                }

            # Log the output
            log_trace(
                log_id,
                "criminality_agent",
                {
                    "raw_output": raw_output,
                    "parsed_result": result,
                },
            )

            # Print for debugging
            print(f"Criminality Agent Output: {result}")

            # Return the result in the expected format
            return {
                "criminality_result": result
            }

        return RunnableLambda(run)

# Define the workflow
def create_metrics_workflow(api_key: str, api_version: str, azure_deployment: str, azure_endpoint: str):
    # Initialize Azure OpenAI LLM with JSON response format
    llm = AzureChatOpenAI(
        api_key=api_key,  # Replace with valid Azure OpenAI API key
        api_version=api_version,  # Recent version
        azure_deployment=azure_deployment,  # Ensure this matches your Azure deployment name
        azure_endpoint=azure_endpoint,  # Replace with valid endpoint, e.g., https://<your-resource>.openai.azure.com/
        response_format={"type": "json_object"},  # Enforce JSON output
        temperature=0  # Reduce randomness for consistent JSON output
    )

    # Initialize MetricsAgents
    agents = MetricsAgents(llm)

    # Node 1: Start Node
    def start_node(input_data: Any) -> GraphState:
        # Handle both dictionary and GraphState inputs
        if isinstance(input_data, dict):
            call_summary = input_data.get("call_summary", "")
        elif isinstance(input_data, GraphState):
            call_summary = input_data.call_summary
        else:
            raise ValueError("Input must be a dictionary or GraphState")

        return GraphState(
            call_summary=call_summary,
            metadata={"start_time": datetime.now().isoformat()}
        )

    # Node 2: Criminality Agent Node
    criminality_node = agents.criminality_agent()

    # Node 3: End Node
    def end_node(state: GraphState) -> Dict[str, Any]:
        log_id = state.metadata.get("start_time", datetime.now().isoformat())
        log_id = log_id.replace(":", "-").replace(".", "_")  # Sanitize for filename
        log_trace(
            log_id,
            "end_node",
            {"state": state.model_dump()},
        )
        print(f"Final Workflow Output: {state.model_dump()}")
        return state.model_dump()

    # Create StateGraph
    workflow = StateGraph(GraphState)

    # Add nodes
    workflow.add_node("start", start_node)
    workflow.add_node("criminality", criminality_node)
    workflow.add_node("end", end_node)

    # Add edges
    workflow.set_entry_point("start")
    workflow.add_edge("start", "criminality")
    workflow.add_edge("criminality", "end")
    workflow.set_finish_point("end")

    # Compile the workflow
    compiled_workflow = workflow.compile()

    return compiled_workflow

# Example usage
if __name__ == "__main__":
    # Azure OpenAI configuration
    api_key = "6ffhCm6wvgxD2LRD7wNZI5sHgqHn4lqYOY7xn8Ycdg7vHvZ8qyujJQQJ99BCACYeBjFXJ3w3AAABACOGwuFA"  # Replace with full API key
    api_version = "2023-07-01-preview"
    azure_deployment = "gpt-4o"
    azure_endpoint = "https://tcoeaiteamgpt4o.openai.azure.com/"  # Replace with full endpoint

    # Create workflow
    workflow = create_metrics_workflow(api_key, api_version, azure_deployment, azure_endpoint)

    # Input data
    input_data = {
        "call_summary": (
            "John Smith called ABC Travel regarding a canceled flight from Chicago to Honolulu on March 15th. "
            "The CSR, Jane, confirmed the cancellation and offered a rebooking option, which John declined, requesting a full refund instead. "
            "Jane processed full refunds for the entire trip, including flights, hotel, and car rental. "
            "John was transferred to a supervisor, Sarah, who apologized and discussed improving service and training to prevent future issues."
        )
    }

    # Execute workflow
    try:
        result = workflow.invoke(input_data)
        print(f"Workflow Result: {result}")
    except Exception as e:
        print(f"Workflow failed: {str(e)}")
