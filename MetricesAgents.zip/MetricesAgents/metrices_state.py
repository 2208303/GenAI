from typing import Optional, Literal, Dict, Any, List
from pydantic import BaseModel


# class GraphState(BaseModel):
#     call_summary: Optional[str] = None

class GraphState(BaseModel):
    call_summary: str
    criminality_result: Dict = {}
    metadata: Dict = {}