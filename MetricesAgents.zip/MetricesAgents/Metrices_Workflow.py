class MetricesAgents:
    def __init__(self, llm):
        self.llm = llm